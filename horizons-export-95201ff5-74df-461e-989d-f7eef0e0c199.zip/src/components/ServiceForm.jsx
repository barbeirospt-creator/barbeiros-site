import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { serviceService } from '@/services/serviceService';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

export const ServiceForm = ({ open, onClose, serviceToEdit, barbershopId, onSave }) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    duration: '',
    description: ''
  });

  useEffect(() => {
    if (serviceToEdit) {
      setFormData({
        name: serviceToEdit.name,
        price: serviceToEdit.price,
        duration: serviceToEdit.duration,
        description: serviceToEdit.description || ''
      });
    } else {
      setFormData({ name: '', price: '', duration: '', description: '' });
    }
  }, [serviceToEdit, open]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.price <= 0 || formData.duration <= 0) {
      toast({ title: "Erro", description: "Preço e duração devem ser maiores que zero.", variant: "destructive" });
      return;
    }
    
    setLoading(true);
    try {
      let result;
      if (serviceToEdit) {
        result = await serviceService.updateService(serviceToEdit.id, formData);
      } else {
        result = await serviceService.createService({ ...formData, barbershopId });
      }

      if (result.error) throw result.error;

      toast({ title: "Sucesso!", description: "Serviço guardado com sucesso!" });
      onSave();
      onClose();
    } catch (error) {
      console.error(error);
      toast({ title: "Erro", description: "Falha ao guardar serviço.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{serviceToEdit ? 'Editar Serviço' : 'Novo Serviço'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Nome do Serviço</label>
            <Input 
              required
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
              placeholder="Ex: Corte de Cabelo"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Preço (€)</label>
              <Input 
                type="number"
                min="0"
                step="0.01"
                required
                value={formData.price}
                onChange={e => setFormData({...formData, price: e.target.value})}
                placeholder="15.00"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Duração (min)</label>
              <Input 
                type="number"
                min="1"
                required
                value={formData.duration}
                onChange={e => setFormData({...formData, duration: e.target.value})}
                placeholder="30"
              />
            </div>
          </div>
          <div>
            <label className="text-sm font-medium">Descrição</label>
            <Input 
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
              placeholder="Opcional"
            />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? 'A guardar...' : 'Guardar Serviço'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};