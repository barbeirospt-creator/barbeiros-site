import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Clock, Scissors, ChevronRight, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

export const ServicesAndPricing = ({ services, barbershopName }) => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState('Todos');

  const categories = ['Todos', ...new Set(services.map(s => s.category))];

  const filteredServices = selectedCategory === 'Todos'
    ? services
    : services.filter(s => s.category === selectedCategory);

  const handleBook = (service) => {
    navigate('/agendamentos', { state: { service, barbershopName } });
  };

  return (
    <div className="space-y-6">
      {/* Category Filter */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {categories.map((category) => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap ${
              selectedCategory === category 
                ? 'bg-primary text-white' 
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {category}
          </button>
        ))}
      </div>

      {/* Promotions Banner */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6 rounded-xl shadow-lg relative overflow-hidden">
        <div className="relative z-10">
          <h3 className="text-xl font-bold mb-2">Oferta Especial de Inverno!</h3>
          <p className="opacity-90 mb-4">Reserve o Combo Corte + Barba e ganhe 10% de desconto extra.</p>
          <Button variant="secondary" size="sm" className="font-bold text-purple-700">
            Aproveitar Oferta
          </Button>
        </div>
        <Scissors className="absolute -right-4 -bottom-4 w-32 h-32 text-white/10 rotate-12" />
      </div>

      {/* Services List */}
      <div className="grid gap-4">
        {filteredServices.map((service, index) => (
          <motion.div
            key={service.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow flex flex-col sm:flex-row justify-between items-center gap-4"
          >
            <div className="flex-1 text-center sm:text-left">
              <h4 className="font-bold text-slate-900 text-lg">{service.name}</h4>
              <div className="flex items-center justify-center sm:justify-start gap-4 mt-1 text-sm text-slate-500">
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" /> {service.duration} min
                </span>
                <span className="bg-slate-100 px-2 py-0.5 rounded text-xs uppercase tracking-wider font-semibold">
                  {service.category}
                </span>
              </div>
            </div>
            
            <div className="flex items-center gap-6 w-full sm:w-auto justify-between sm:justify-end">
              <span className="text-xl font-bold text-slate-900">{service.price.toFixed(2)}€</span>
              <Button onClick={() => handleBook(service)} className="gap-2">
                Agendar
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Info Footer */}
      <div className="bg-slate-50 p-4 rounded-lg text-sm text-slate-500 flex gap-2 items-start">
        <div className="bg-blue-100 p-1 rounded-full mt-0.5">
          <Check className="w-3 h-3 text-blue-600" />
        </div>
        <p>Todos os serviços incluem lavagem e finalização com produtos premium. IVA incluído à taxa legal em vigor.</p>
      </div>
    </div>
  );
};