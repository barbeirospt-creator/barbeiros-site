import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Store } from 'lucide-react';
import { motion } from 'framer-motion';

export default function ShowcasePreviewCard({ showcase }) {
  const navigate = useNavigate();
  
  // Use first photo if available, otherwise fallback
  const imageUrl = showcase.business_photos?.[0]?.image_url || null;

  return (
    <motion.div
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      onClick={() => navigate(`/showcase/${showcase.id}`)}
      className="relative overflow-hidden rounded-xl bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 hover:border-[#FFD700] hover:shadow-2xl hover:shadow-[#FFD700]/20 transition-all duration-300 cursor-pointer group flex-shrink-0 w-48 h-32 mr-3"
    >
      {/* Background Image or Fallback */}
      <div className="absolute inset-0 bg-black/60 z-10 group-hover:bg-black/40 transition-colors duration-300" />
      {imageUrl ? (
        <img 
          src={imageUrl} 
          alt={showcase.business_name || 'Business'} 
          className="absolute inset-0 w-full h-full object-cover"
        />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-r from-purple-900 to-indigo-900">
          <Store className="w-8 h-8 text-white/30" />
        </div>
      )}

      {/* Content */}
      <div className="relative z-20 h-full p-3 flex flex-col justify-end">
        <h4 className="text-white font-bold text-sm truncate drop-shadow-md">
          {showcase.business_name || 'Barbearia Sem Nome'}
        </h4>
        <p className="text-gray-300 text-xs truncate drop-shadow-md">
          {showcase.profiles?.display_name || showcase.profiles?.full_name || 'Utilizador Anónimo'}
        </p>
      </div>
      
      {/* Gradient Border Overlay */}
      <div className="absolute inset-0 rounded-xl ring-1 ring-inset ring-white/10 group-hover:ring-[#FFD700]/50 transition-all duration-300 z-30 pointer-events-none" />
    </motion.div>
  );
}