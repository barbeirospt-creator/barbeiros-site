
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Home, MessageSquare, ShoppingBag } from "lucide-react";
import { motion } from "framer-motion";

export default function SidebarApp() {
  const location = useLocation();

  const navItems = [
    { path: "/", label: "Dashboard", icon: Home },
    { path: "/forum", label: "Fórum", icon: MessageSquare },
    { path: "/group-purchases", label: "Compras em Grupo", icon: ShoppingBag },
  ];

  return (
    <div className="w-64 bg-black border-r border-zinc-800 min-h-screen p-4 flex flex-col gap-8 shrink-0 hidden md:flex">
      <div className="px-4 mt-6">
        <h1 className="text-2xl font-bold text-[#FFD700] tracking-tight">
          Barbeiros<span className="text-white">.pt</span>
        </h1>
      </div>
      
      <nav className="flex flex-col gap-2">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path || (item.path !== "/" && location.pathname.startsWith(item.path));
          const Icon = item.icon;
          
          return (
            <Link key={item.path} to={item.path}>
              <motion.div
                whileHover={{ scale: 1.02, backgroundColor: isActive ? "#FFD700" : "rgba(255, 215, 0, 0.1)" }}
                whileTap={{ scale: 0.98 }}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                  isActive 
                    ? "bg-[#FFD700] text-black font-bold" 
                    : "text-zinc-400 hover:text-[#FFD700]"
                }`}
              >
                <Icon size={20} className={isActive ? "text-black" : "text-current"} />
                <span>{item.label}</span>
              </motion.div>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
