
import React from 'react';
import { Link } from 'react-router-dom';

export default function SimpleNavigation() {
  return (
    <nav style={{ marginBottom: '20px', display: 'flex', gap: '15px' }}>
      <Link to="/dashboard">Dashboard</Link>
      <Link to="/forum">Fórum</Link>
      <Link to="/group-purchases">Compras em Grupo</Link>
    </nav>
  );
}
