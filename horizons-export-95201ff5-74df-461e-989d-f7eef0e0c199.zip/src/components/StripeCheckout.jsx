import React, { useState } from 'react';
import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { paymentService } from '@/services/paymentService';
import { useAuth } from '@/contexts/AuthContext';
import { PaymentErrorHandler } from '@/components/PaymentErrorHandler';
import { Lock, Loader2 } from 'lucide-react';

export const StripeCheckout = ({ appointment, onSuccess }) => {
  const { user } = useAuth();
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError(null);

    // 1. Security Validations
    if (!user) {
      setError("Utilizador não autenticado.");
      return;
    }
    if (!appointment || !appointment.id) {
       setError("Dados do agendamento inválidos.");
       return;
    }
    if (!stripe || !elements) return;

    setLoading(true);

    try {
      // 2. Create Payment Intent
      const { clientSecret, error: intentError } = await paymentService.createPaymentIntent({
        appointmentId: appointment.id,
        barbershopId: appointment.barbershopId,
        customerEmail: user.email,
        userId: user.id
      });

      if (intentError) throw new Error(intentError);
      if (!clientSecret) throw new Error("Falha ao iniciar pagamento.");

      // 3. Confirm Card Payment
      const result = await stripe.confirmCardPayment(clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement),
          billing_details: {
            email: user.email,
            name: user.user_metadata?.name || 'Cliente',
          },
        },
      });

      if (result.error) {
        throw result.error;
      } else if (result.paymentIntent.status === 'succeeded') {
        toast({ title: "Sucesso", description: "Pagamento confirmado!" });
        if (onSuccess) onSuccess(result.paymentIntent);
      }

    } catch (err) {
      console.error("Checkout Error:", err);
      setError(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentErrorHandler error={error} onRetry={() => setError(null)} />

      <div className="bg-white p-4 border border-slate-300 rounded-md">
        <CardElement options={{
          style: {
            base: {
              fontSize: '16px',
              color: '#424770',
              '::placeholder': { color: '#aab7c4' },
            },
            invalid: { color: '#9e2146' },
          },
        }} />
      </div>

      <div className="flex items-center justify-between text-sm text-slate-500 mb-4">
        <div className="flex items-center gap-1">
          <Lock className="w-3 h-3" /> Encriptação SSL de 256-bits
        </div>
        <div>
          Powered by Stripe
        </div>
      </div>

      <Button type="submit" className="w-full h-12 text-lg" disabled={!stripe || loading}>
        {loading ? (
          <>
            <Loader2 className="w-5 h-5 mr-2 animate-spin" /> A processar...
          </>
        ) : (
          `Pagar ${appointment.price ? appointment.price.toFixed(2) : '0.00'}€`
        )}
      </Button>
    </form>
  );
};