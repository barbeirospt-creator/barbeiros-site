import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { paymentService } from '@/services/paymentService';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Loader2, Check } from 'lucide-react';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { PaymentErrorHandler } from '@/components/PaymentErrorHandler';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY || 'pk_live_cJ180iBeKVUsAXURG2WM29bU002HLZ4Mvb');

const CheckoutForm = ({ selectedPlan, onSuccess }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!stripe || !elements || !selectedPlan) return;
    
    setLoading(true);
    setError(null);

    try {
      // 1. Create Subscription
      const { clientSecret, error: subError } = await paymentService.createSubscription({
        userId: user.id,
        planType: selectedPlan.type,
        email: user.email,
        barbershopId: user.user_metadata?.barbershopId
      });

      if (subError) throw new Error(subError);

      // 2. Confirm Payment if clientSecret exists (paid plans)
      if (clientSecret) {
        const result = await stripe.confirmCardPayment(clientSecret, {
           payment_method: {
             card: elements.getElement(CardElement),
             billing_details: { email: user.email }
           }
        });
        if (result.error) throw result.error;
      }

      onSuccess();
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentErrorHandler error={error} onRetry={() => setError(null)} />
      
      <div className="p-4 border border-slate-200 rounded-md bg-white">
        <CardElement />
      </div>

      <Button type="submit" className="w-full" disabled={loading || !stripe}>
        {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
        Subscrever {selectedPlan.name} ({selectedPlan.price}€/mês)
      </Button>
    </form>
  );
};

export const SubscriptionCheckout = () => {
  const { user } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [success, setSuccess] = useState(false);

  const plans = [
    { type: 'basic', name: 'Básico', price: 0, features: ['Listagem', '50 Agendamentos'] },
    { type: 'professional', name: 'Profissional', price: 9.90, features: ['Ilimitado', 'Analíticas', 'SMS'] },
    { type: 'premium', name: 'Premium', price: 29.00, features: ['App Própria', 'Suporte VIP'] }
  ];

  if (success) {
     return (
        <div className="max-w-md mx-auto mt-20 text-center p-8 bg-white rounded-xl shadow-lg border border-green-100">
           <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Check className="w-8 h-8 text-green-600" />
           </div>
           <h2 className="text-2xl font-bold mb-2">Subscrição Ativa!</h2>
           <p className="text-slate-600">O seu plano foi atualizado com sucesso.</p>
           <Button className="mt-6" onClick={() => window.location.href='/dashboard'}>Ir para o Painel</Button>
        </div>
     );
  }

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <h1 className="text-3xl font-bold text-center mb-10">Escolha o seu Plano</h1>
      
      {!selectedPlan ? (
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map(plan => (
            <div key={plan.type} className="border p-6 rounded-xl hover:border-primary transition-colors cursor-pointer bg-white" onClick={() => setSelectedPlan(plan)}>
              <h3 className="text-xl font-bold">{plan.name}</h3>
              <p className="text-2xl font-bold text-primary mt-2">{plan.price}€<span className="text-sm font-normal text-slate-500">/mês</span></p>
              <ul className="mt-4 space-y-2 text-sm text-slate-600">
                {plan.features.map(f => <li key={f} className="flex gap-2"><Check className="w-4 h-4 text-green-500"/> {f}</li>)}
              </ul>
              <Button className="w-full mt-6" variant="outline">Selecionar</Button>
            </div>
          ))}
        </div>
      ) : (
        <div className="max-w-md mx-auto">
          <div className="mb-6 flex justify-between items-center">
             <h2 className="text-xl font-bold">Pagamento: {selectedPlan.name}</h2>
             <button onClick={() => setSelectedPlan(null)} className="text-sm text-slate-500 hover:text-primary">Alterar Plano</button>
          </div>
          <Elements stripe={stripePromise}>
            <CheckoutForm selectedPlan={selectedPlan} onSuccess={() => setSuccess(true)} />
          </Elements>
        </div>
      )}
    </div>
  );
};