import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Check, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { paymentService } from '@/services/paymentService';
import { useStripe } from '@stripe/react-stripe-js';
import { useToast } from '@/components/ui/use-toast';

const PlanCard = ({ title, price, features, recommended, type, onSelect, loading }) => (
  <div className={`relative p-8 rounded-2xl border ${recommended ? 'border-primary shadow-lg scale-105 bg-white' : 'border-slate-200 bg-white shadow-sm'} flex flex-col`}>
    {recommended && (
      <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide">
        Mais Popular
      </div>
    )}
    <h3 className="text-xl font-bold mb-2">{title}</h3>
    <div className="mb-6">
      <span className="text-4xl font-bold">€{price}</span>
      <span className="text-slate-500">/mês</span>
    </div>
    <ul className="space-y-4 mb-8 flex-1">
      {features.map((feature, i) => (
        <li key={i} className="flex items-start gap-3 text-sm text-slate-600">
          <Check className="w-5 h-5 text-primary shrink-0" />
          <span>{feature}</span>
        </li>
      ))}
    </ul>
    <Button 
      onClick={() => onSelect(type)} 
      variant={recommended ? 'default' : 'outline'}
      className="w-full"
      disabled={loading}
    >
      {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
      Escolher {title}
    </Button>
  </div>
);

export const SubscriptionPlans = () => {
  const { user } = useAuth();
  const stripe = useStripe();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async (planType) => {
    if (!user) return;
    setLoading(true);
    try {
      const { clientSecret, subscriptionId } = await paymentService.createSubscription({
        userId: user.id,
        planType,
        barbershopId: null,
        email: user.email
      });

      const { error } = await stripe.confirmCardPayment(clientSecret);
      
      if (error) {
        toast({ title: "Erro", description: error.message, variant: "destructive" });
      } else {
        toast({ title: "Sucesso!", description: "Plano subscrito com sucesso." });
      }
    } catch (err) {
      toast({ title: "Erro", description: "Falha ao processar subscrição.", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="py-12 px-4 max-w-6xl mx-auto">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold mb-4">Escolha o seu plano</h2>
        <p className="text-slate-600">Soluções flexíveis para o crescimento do seu negócio</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8 items-start">
        <PlanCard 
          title="Básico" 
          price="0" 
          type="basic"
          features={['Perfil da Barbearia', 'Até 50 agendamentos/mês', 'Listagem no diretório']} 
          onSelect={handleSubscribe}
          loading={loading}
        />
        <PlanCard 
          title="Profissional" 
          price="9.90" 
          type="professional"
          recommended={true}
          features={['Agendamentos ilimitados', 'Painel de analíticas', 'Gestão de equipa (até 3)', 'SMS de lembrete', 'Comissão de 15%']} 
          onSelect={handleSubscribe}
          loading={loading}
        />
        <PlanCard 
          title="Premium" 
          price="29.00" 
          type="premium"
          features={['Tudo do Profissional', 'App personalizada', 'Reforço de marketing', 'Suporte prioritário', 'Comissão de 20%']} 
          onSelect={handleSubscribe}
          loading={loading}
        />
      </div>
    </div>
  );
};