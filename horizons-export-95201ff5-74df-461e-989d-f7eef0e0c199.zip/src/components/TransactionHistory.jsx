import React, { useState, useEffect } from 'react';
import { paymentService } from '@/services/paymentService';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Download, FileText } from 'lucide-react';
import { Link } from 'react-router-dom';

export const TransactionHistory = () => {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    async function load() {
      if (!user) return;
      try {
        const data = await paymentService.getUserTransactions(user.id);
        setTransactions(data || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [user]);

  const filtered = transactions.filter(t => filter === 'all' ? true : t.status === filter);

  const downloadCSV = () => {
    const headers = ['Data', 'Descrição', 'Valor', 'Estado', 'ID Transação'];
    const rows = filtered.map(t => [
      new Date(t.data).toLocaleDateString('pt-PT'),
      t.descricao,
      t.valor,
      t.status,
      t.id
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "transacoes.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) return <div className="p-8 text-center">A carregar transações...</div>;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div className="p-6 border-b border-slate-200 flex flex-col sm:flex-row justify-between items-center gap-4">
        <h3 className="text-lg font-bold">Histórico de Transações</h3>
        <div className="flex gap-2">
           <select 
             className="border rounded-md px-3 py-2 text-sm text-gray-900"
             value={filter}
             onChange={(e) => setFilter(e.target.value)}
           >
             <option value="all">Todos</option>
             <option value="completed">Concluídos</option>
             <option value="pending">Pendentes</option>
             <option value="refunded">Reembolsados</option>
           </select>
           <Button variant="outline" size="sm" onClick={downloadCSV} className="gap-2">
             <Download className="w-4 h-4" /> Exportar
           </Button>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="bg-slate-50 text-slate-600 font-medium border-b">
            <tr>
              <th className="px-6 py-4">Data</th>
              <th className="px-6 py-4">Descrição</th>
              <th className="px-6 py-4">Valor</th>
              <th className="px-6 py-4">Estado</th>
              <th className="px-6 py-4 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.length === 0 && (
               <tr><td colSpan="5" className="px-6 py-8 text-center text-slate-500">Nenhuma transação encontrada.</td></tr>
            )}
            {filtered.map((t) => (
              <tr key={t.id} className="hover:bg-slate-50">
                <td className="px-6 py-4">{new Date(t.data).toLocaleDateString('pt-PT')}</td>
                <td className="px-6 py-4 font-medium">{t.descricao}</td>
                <td className="px-6 py-4">{t.valor.toFixed(2)}€</td>
                <td className="px-6 py-4">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium capitalize
                    ${t.status === 'completed' ? 'bg-green-100 text-green-800' : 
                      t.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}`}>
                    {t.status === 'completed' ? 'Concluído' : t.status === 'pending' ? 'Pendente' : 'Reembolsado'}
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                   <Link to={`/receipt/${t.id}`} className="text-primary hover:underline text-xs flex items-center justify-end gap-1">
                     <FileText className="w-3 h-3" /> Recibo
                   </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};