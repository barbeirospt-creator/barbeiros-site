
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, User } from 'lucide-react';

export function ForumReplyItem({ reply }) {
  const authorName = reply.profiles?.full_name || reply.profiles?.email?.split('@')[0] || 'Usuário Anónimo';

  return (
    <Card className={`mb-4 bg-zinc-900 border-zinc-800 ${reply.is_solution ? 'border-green-500/50 bg-green-500/5' : ''}`}>
      <CardContent className="p-6">
        <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">
          <div className="flex items-center sm:flex-col sm:w-32 shrink-0 gap-3 sm:text-center">
            <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center overflow-hidden">
               {reply.profiles?.avatar_url ? (
                 <img src={reply.profiles.avatar_url} alt={authorName} className="w-full h-full object-cover" />
               ) : (
                 <User className="w-5 h-5 text-zinc-500" />
               )}
            </div>
            <div className="flex-1 text-left sm:text-center">
              <p className="text-xs font-medium text-white truncate w-full" title={authorName}>{authorName}</p>
              {reply.profiles?.email && (
                 <p className="text-[10px] text-zinc-500 truncate w-full" title={reply.profiles.email}>{reply.profiles.email}</p>
              )}
              <p className="text-[10px] text-zinc-500 sm:mt-1">{new Date(reply.created_at).toLocaleDateString()}</p>
            </div>
          </div>
          <div className="flex-1">
            {reply.is_solution && (
              <Badge className="bg-green-500/20 text-green-400 hover:bg-green-500/20 mb-3">
                <CheckCircle2 className="w-3 h-3 mr-1" /> Solução
              </Badge>
            )}
            <div className="text-zinc-300 text-sm whitespace-pre-wrap leading-relaxed">
              {reply.content}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
