
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { MessageSquare, Users, ShieldAlert } from 'lucide-react';

export function ForumStats({ stats }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
      <Card className="bg-zinc-900 border-zinc-800">
        <CardContent className="p-6 flex items-center gap-4">
          <div className="p-3 bg-[#FCD34D]/10 rounded-lg text-[#FCD34D]">
            <MessageSquare className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-gray-500">Total de Tópicos</p>
            <p className="text-2xl font-bold text-white">{stats?.totalTopics || 0}</p>
          </div>
        </CardContent>
      </Card>
      
      <Card className="bg-zinc-900 border-zinc-800">
        <CardContent className="p-6 flex items-center gap-4">
          <div className="p-3 bg-blue-500/10 rounded-lg text-blue-500">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-gray-500">Membros Ativos</p>
            <p className="text-2xl font-bold text-white">{stats?.activeMembers || 0}</p>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-zinc-900 border-zinc-800">
        <CardContent className="p-6 flex items-center gap-4">
          <div className="p-3 bg-yellow-500/10 rounded-lg text-yellow-500">
            <ShieldAlert className="w-6 h-6" />
          </div>
          <div>
            <p className="text-sm text-gray-500">Aguardando Moderação</p>
            <p className="text-2xl font-bold text-white">{stats?.pendingModeration || 0}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
