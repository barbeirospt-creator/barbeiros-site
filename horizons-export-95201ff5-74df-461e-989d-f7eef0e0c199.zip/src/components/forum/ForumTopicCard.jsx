
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, Eye, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

export function ForumTopicCard({ topic }) {
  // Use explicit fallbacks for author details without relying on relationships
  const authorName = topic.profiles?.full_name || topic.profiles?.email?.split('@')[0] || 'Usuário Anónimo';
  
  return (
    <Link to={`/forum/${topic.id}`}>
      <Card className="hover:border-[#FCD34D] transition-colors bg-zinc-900 border-zinc-800 cursor-pointer mb-4">
        <CardContent className="p-6">
          <div className="flex justify-between items-start gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                {topic.category && (
                  <Badge variant="outline" className="bg-zinc-800 text-zinc-300 border-none uppercase text-[10px]">
                    {topic.category}
                  </Badge>
                )}
                {topic.status === 'pending' && <Badge variant="outline" className="text-yellow-500 uppercase text-[10px]">Pendente</Badge>}
                {topic.status === 'blocked' && <Badge variant="destructive" className="uppercase text-[10px]">Bloqueado</Badge>}
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{topic.name || topic.title}</h3>
              <p className="text-gray-400 line-clamp-2">{topic.description || topic.content}</p>
            </div>
            
            <div className="flex flex-col items-end gap-2 text-sm text-gray-500 min-w-[120px]">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4" />
                <span>{topic.replies_count || 0}</span>
              </div>
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4" />
                <span>{topic.views_count || 0}</span>
              </div>
            </div>
          </div>
          
          <div className="mt-4 flex items-center gap-4 text-xs text-gray-500 border-t border-zinc-800 pt-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-zinc-800 overflow-hidden flex items-center justify-center">
                {topic.profiles?.avatar_url ? (
                  <img src={topic.profiles.avatar_url} alt={authorName} className="w-full h-full object-cover" />
                ) : (
                  <span className="text-[10px] text-zinc-400">{authorName.charAt(0).toUpperCase()}</span>
                )}
              </div>
              <span className="text-gray-300 truncate max-w-[150px]">{authorName}</span>
              {topic.profiles?.email && <span className="text-zinc-600 hidden sm:inline">({topic.profiles.email})</span>}
            </div>
            <div className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              <span>{new Date(topic.created_at).toLocaleDateString()}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
