
import React from 'react';
import { Button } from '@/components/ui/button';
import { Check, X, ShieldAlert } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useForumManagement } from '@/hooks/useForumManagement';

export function ModerationPanel({ targetId, targetType, currentStatus, onModerated }) {
  const { toast } = useToast();
  const { moderateContent, loading } = useForumManagement();

  const handleAction = async (action) => {
    try {
      await moderateContent({ target_id: targetId, target_type: targetType, mod_action: action, reason: 'Moderated by admin' });
      toast({ title: "Sucesso", description: `Conteúdo ${action === 'approve' ? 'aprovado' : 'rejeitado'}.` });
      if (onModerated) onModerated();
    } catch (err) {
      toast({ variant: "destructive", title: "Erro", description: err.message });
    }
  };

  if (currentStatus === 'approved') return null;

  return (
    <div className="flex items-center gap-2 p-3 bg-zinc-900 border border-zinc-800 rounded-lg mt-4">
      <ShieldAlert className="w-5 h-5 text-yellow-500" />
      <span className="text-sm text-gray-300 flex-1">Ação de Moderação Necessária</span>
      <Button size="sm" variant="outline" className="bg-green-500/10 text-green-500 hover:bg-green-500/20 border-green-500/20" onClick={() => handleAction('approve')} disabled={loading}>
        <Check className="w-4 h-4 mr-1" /> Aprovar
      </Button>
      <Button size="sm" variant="outline" className="bg-red-500/10 text-red-500 hover:bg-red-500/20 border-red-500/20" onClick={() => handleAction('reject')} disabled={loading}>
        <X className="w-4 h-4 mr-1" /> Rejeitar
      </Button>
    </div>
  );
}
